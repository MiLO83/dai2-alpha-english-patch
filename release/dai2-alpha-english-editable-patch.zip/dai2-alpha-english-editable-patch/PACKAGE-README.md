# Dai-2 Alpha editable patch package

Start with **[README.md](README.md)**. It contains the spreadsheet tutorial,
column-selection rules, three-page dialogue examples, DTE capacity explanation,
stock ISO hash, and troubleshooting guide.

1. Extract the entire package into one directory on Linux x86-64 or Ubuntu/WSL.
2. Supply Python 3.10+ with venv/pip support. The first build installs Pillow.
3. Put your matching clean Japanese disc image at `original/SLPS-25228.iso`.
4. Run `./tools/run-tsv-editor.sh` and open `http://127.0.0.1:8765/`.
5. Open `translation/all-known-game-text.tsv`, edit the green Hand Translated
   cells, save, and click **Generate ISO** or **Generate Patch**.

Required source size: **2,501,378,048 bytes**. Required SHA-256:

```text
1f63e4acb06a689221a021a693063291d9448bb71776e6bd3d2da050de3cefdd
```

The builder preserves the clean source and writes its output under `build/`.
Nonempty hand translations replace the entire entry in column order; all three
must be empty to use the machine translation. Extra pages apply only to dialogue.

The ZIP includes an internal `SHA256SUMS` inventory. From this directory:

```sh
sha256sum -c SHA256SUMS
```

This package contains no ISO, BIOS, emulator, extracted executable/scenario/font,
memory card, or savestate. The bundled xdelta3 binary's corresponding source
and notices are in `third_party/xdelta3/`; font notices are in `assets/`.
Retain those materials when redistributing the package.
