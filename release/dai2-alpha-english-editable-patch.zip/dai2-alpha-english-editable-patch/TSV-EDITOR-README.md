# Local spreadsheet editor: quick reference

The full walkthrough is the [README tutorial](README.md#tutorial-from-one-edit-to-a-playable-iso).
For TSV/control-code details, see [translation/EDITING.md](translation/EDITING.md).

## Start and open

```sh
./tools/run-tsv-editor.sh
```

Open `http://127.0.0.1:8765/`, then use **Open TSV** to select
`translation/all-known-game-text.tsv`. Keep the terminal running for builds.
Use `--port 8766 --no-browser` if you need another port or prefer to open the
browser yourself. Double-clicking the HTML supports editing but not ISO builds.

## Columns and playback

Japanese and machine-translated English are reference panes. The three green
**Hand Translated 1–3** panes supply the replacement dialogue pages. The first
nonempty hand translation replaces the original entry; further nonempty cells
follow before the next original entry. Empty cells are skipped. Only when all
three are empty does the builder select machine English, then Japanese.

The game follows its original sequence, not spreadsheet row order. Extra pages
retain the original speaker/portrait metadata. Each completed inserted box
should take one normal dialogue-advance press. See
[the runtime notes](docs/DIALOGUE-PAGES.md) for queued/sequential ordering.

## Editing and saving

- Filter across columns, choose a scope, and page through 50–500 rows at a time.
- The text-area proportions are approximately 25% Japanese, 25% machine
  English, and 50% shared by the three hand-translation cells.
- Dialogue supports three lines of up to 44 English characters per page.
  Whole-word overflow flows to the next hand-translation cell. Text beyond the
  last page's capacity is preserved and flagged; shorten it before building.
- Extra pages are disabled for UI/title rows. UI fields have separate byte
  limits; title rows are not currently inserted by the editor build.
- **Save** updates the opened file where browser support permits; **Save As**
  creates a checkpoint. Other browsers download a TSV instead.
- **Recovery autosave** keeps an optional private browser draft, not a disk save.
  Closing a dirty document triggers the browser's own unsaved-exit warning.

## Build outputs

| Button | Result |
| --- | --- |
| Generate ISO | `build/SLPS-25228-English-web-edited.iso` |
| Generate Patch | Rebuilds that ISO, then creates `build/SLPS-25228-English-web-edited.xdelta` |

Both use the current table in memory, with confirmation for unsaved edits.
They do not save the opened TSV. The helper stores the most recently submitted
table at `work/web-editor/current-translation.tsv` and prints progress and the
output hash in the build dialog. Later builds replace the same output files.

Provide the verified stock image described in the [README](README.md#the-stock-iso-and-its-sha-256).
The web workflow preserves the bundled native English title logo and five
intro cards. A legacy dialogue-only TSV keeps packaged UI translations.

Use one build at a time, including command-line jobs. Test a new ISO by booting
fresh rather than restoring an older emulator savestate. Save your spreadsheet
before closing the browser and press `Ctrl+C` in the launcher terminal to stop.
