# Hand-translated dialogue pages

The first nonempty hand translation replaces an original command's text.
Remaining nonempty cells become distinct resident copies of that command,
with only the text pointer changed. Spreadsheet row order does not determine
gameplay order: original scenario commands and branches remain in place.

## Completion hook and original order

The hook replaces the call at `0x208364` in the script-owner completion wrapper.
Disassembly of the verified original executable establishes two playback modes:

- `0x205a40` fetches the current command. When byte `state+4` is zero,
  it uses `state+0xc`. Otherwise it calls `0x206490`, which fetches
  `state+0x94+4*index`, where `index` is stored at `state+0xd8`.
- `0x2059d0` advances sequential commands by 24 bytes, but in queued mode
  calls `0x206440` to increment the queue index instead.
- The prescanner at `0x206520` moves `state+0xc` ahead while assembling the
  queue. This cursor cannot identify the displayed dialogue in queued mode.
- After the completion wrapper returns, `0x208280` calls `0x207030` to
  display the next command through the current-command getter.

The earlier redirect matched `original_command+24` against `state+0xc` and
always assumed stock advancement added 24. That could match a later command
while an earlier queued box was displayed. Its tests modeled only the addition
and therefore did not establish gameplay ordering.

The corrected hook resolves the active slot using the stock getter's mode rules.
For an extra page, it replaces that slot with the resident command and returns
it directly, without advancing the original queue or sequential stream. On
completion of the final extra page, it restores the original command in the
slot and tail-calls stock advancement exactly once. Restoring queued slots also
allows the sequence to be revisited without retaining resident pointers.

Each mapping checks the scenario member's 32-byte name at its load address,
because different scenario members reuse command addresses in RAM. The hook
does not modify the prescanner or reorder the original queue.

## Verification

Run `python3 -m unittest discover -s tools -p 'test_dialogue_pages.py' -v`.
The tests execute the emitted MIPS instructions, including branch delay slots,
with the disassembled stock getter/advance semantics. They cover both modes,
adjacent translated entries, one/two extra pages, revisits, unrelated members
sharing a command address, and all eight empty/nonempty spreadsheet combinations.

These are instruction-level checks, not a controller or rendering test. Boot a
newly built ISO in PCSX2 or on PS2 to verify visible ordering and one normal
advance press per completed box. A savestate created with an older executable
can restore old code and resident data; use a fresh boot and an in-game save.
