# Bundled xdelta3

`tools/xdelta3` is the unmodified Linux x86-64 binary from Debian package
`xdelta3_3.0.11-dfsg-1.2_amd64.deb`. Its SHA-256 is:

```text
dc6bdc6ee86b2b3e389c937610c0b2508e31ca53c197de6f9c176909c546a846
```

The corresponding upstream source and Debian build files are included here,
along with the Debian source manifest, copyright notice, and GPL version 2.
The two source archives were checked against the SHA-256 fields in the `.dsc`.

Source distribution: [Debian xdelta3 pool](https://deb.debian.org/debian/pool/main/x/xdelta3/).
Upstream project: [jmacd/xdelta](https://github.com/jmacd/xdelta/).

To unpack the corresponding source on Debian/Ubuntu with `dpkg-dev` installed:

```sh
dpkg-source -x xdelta3_3.0.11-dfsg-1.2.dsc
```

The Debian build requirements and packaging instructions are contained in the
`.dsc` and `debian.tar.xz`. See `copyright` and `COPYING` for license terms.
