-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256

Format: 3.0 (quilt)
Source: xdelta3
Binary: xdelta3
Architecture: any
Version: 3.0.11-dfsg-1.2
Maintainer: A Mennucc1 <mennucc1@debian.org>
Homepage: http://xdelta.org/
Standards-Version: 4.6.0
Vcs-Browser: https://salsa.debian.org/debian/xdelta3
Vcs-Git: https://salsa.debian.org/debian/xdelta3.git
Testsuite: autopkgtest
Testsuite-Triggers: build-essential, liblzma-dev
Build-Depends: debhelper-compat (= 13), liblzma-dev
Package-List:
 xdelta3 deb utils optional arch=any
Checksums-Sha1:
 a3f533a7d6898c3903d8dfdb583081ee98bab576 435124 xdelta3_3.0.11-dfsg.orig.tar.xz
 f0c42734fabcbd1312fbac45a102307ae4fd44ff 8324 xdelta3_3.0.11-dfsg-1.2.debian.tar.xz
Checksums-Sha256:
 c730bf7a526eea39c1a371632c1abc980e7281bf5d1fead79d663de303498f5f 435124 xdelta3_3.0.11-dfsg.orig.tar.xz
 85b536ff38fd5a4ef9be28e74c96e310e2f3a9a58bc55738f57efe119e6a4f5a 8324 xdelta3_3.0.11-dfsg-1.2.debian.tar.xz
Files:
 554d598c7d10765953f6e61af23bea55 435124 xdelta3_3.0.11-dfsg.orig.tar.xz
 6d2d7e83096381b79717b14c14994c17 8324 xdelta3_3.0.11-dfsg-1.2.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQJFBAEBCAAvFiEE8fAHMgoDVUHwpmPKV4oElNHGRtEFAmIZRjsRHHRpbGxlQGRl
Ymlhbi5vcmcACgkQV4oElNHGRtHILg/+OVGxYIBoSPoIY5eo2C0zJvMkc8G8uf7U
c+6RlvAH+A6w2qJkKorCeF36lTI+ppcBN3+AqgzPbiCCKRknPH3bYPaXv76PVQJp
8QTc90QItkMMbpILSeDnX+bi8BbkpqArbMEPDAAEOfZlI1b0O4U8Hj5kvIvBp5G+
nB55/LZUV1Lg1XQ5sHM4hQ0934fCn/yoCiMToP27cAUvYotKkW8r08J6NuIgfsmA
yT8WkUWT75lj+u50X+ousalSeetE8iYZWWTqFhej6yUHnCg9v5kG6ggBY7cJqO9h
Z4ZmTMFxnKbcBGgWt9trk6lVBLZbnIxko85hINQjGxJ3/FC22dJFtn+Ynv/HQl9i
9mAxDiUA4+gxTqLVfLWcwiXTcvVpzIsWCRQ1CR2brnM1CQSH27kOPymg8zA50sqr
XrYPqIhG99x7XO730z4ypDlbZsVVny4JFaZT1hVs7DAzSXbjkwtIG43mDMbv29Qu
Ch6xMrOujFJnze89Za5/Osb47IgeWeQgL2OB5cNkupdY9fl3BvTKW5If8yF16DGI
U/4YUoBlKsN/XuI/3/BF65ezRjC2OHs/jfcdfhmNAUa0d2uW5QqNDHJaspfWDCSZ
sh/sMga1ZIf6NaFItxSDV9aZPhe0cRkoRayUDDE+QM+VqjubjE3qNP66DdHZn44q
osckr+ykgCc=
=uYpW
-----END PGP SIGNATURE-----
