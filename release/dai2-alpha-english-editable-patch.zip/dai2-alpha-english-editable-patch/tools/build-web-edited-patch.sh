#!/usr/bin/env bash
set -euo pipefail

repo_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
table="${1:-$repo_dir/translation/all-known-game-text.tsv}"
source_iso="${2:-$repo_dir/original/SLPS-25228.iso}"
output_iso="${3:-$repo_dir/build/SLPS-25228-English-web-edited.iso}"
output_patch="${4:-$repo_dir/build/SLPS-25228-English-web-edited.xdelta}"

"$repo_dir/tools/build-web-edited-iso.sh" "$table" "$source_iso" "$output_iso"
"$repo_dir/tools/xdelta3" -f -e -s "$source_iso" "$output_iso" "$output_patch"

echo "Built spreadsheet xdelta patch:"
echo "$output_patch"
sha256sum "$output_patch"
