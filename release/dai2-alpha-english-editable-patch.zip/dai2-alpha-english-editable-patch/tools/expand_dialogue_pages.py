#!/usr/bin/env python3
"""Append English dialogue commands and chain them from original commands."""

from __future__ import annotations

import argparse, csv, json, struct
from collections import defaultdict
from pathlib import Path

from dte_codec import encode_whole_page, load_pairs


def align(n: int, a: int = 0x80) -> int:
    return (n + a - 1) & -a


def starts(data: bytes) -> list[int]:
    out=[]; p=0
    while (p := data.find(b"MWo3", p)) >= 0:
        out.append(p); p += 4
    return out


def member_name(data: bytes) -> str:
    return data[0x20:0x40].split(b"\0", 1)[0].decode("ascii")


def locate(clean: bytes, load: int, target: int) -> int | None:
    """Return the unique opcode-1 command whose +0x10 field points at target."""
    found=[]
    for ref in range(0, len(clean)-3, 4):
        if struct.unpack_from("<I", clean, ref)[0] != load + target or ref < 16:
            continue
        command=ref-16
        if struct.unpack_from("<I", clean, command+8)[0] == 1:
            found.append(command)
    unique=list(dict.fromkeys(found))
    return unique[0] if len(unique)==1 else None


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("clean_stage",type=Path); ap.add_argument("patched_stage",type=Path)
    ap.add_argument("occurrences",type=Path); ap.add_argument("table",type=Path)
    ap.add_argument("dte",type=Path); ap.add_argument("output",type=Path)
    ap.add_argument("--continuations",type=Path)
    args=ap.parse_args()
    with args.table.open(encoding="utf-8-sig",newline="") as f:
        table=list(csv.DictReader(f,dialect="excel-tab"))
    pages={r["Original Japanese"]:[(r.get("English Page 2") or "").strip(),(r.get("English Page 3") or "").strip()]
           for r in table if (r.get("English Page 2") or "").strip() or (r.get("English Page 3") or "").strip()}
    if not pages:
        args.output.write_bytes(args.patched_stage.read_bytes()); print("no inserted dialogue pages requested"); return
    with args.occurrences.open(encoding="utf-8",newline="") as f:
        occ=list(csv.DictReader(f,dialect="excel-tab"))
    wanted=defaultdict(list); matched_sources=set()
    for r in occ:
        if r["source"] in pages: wanted[r["member"]].append(r); matched_sources.add(r["source"])
    absent=set(pages)-matched_sources
    if absent:
        raise SystemExit(f"extra pages are dialogue-only; {len(absent)} requested source(s) are not dialogue")
    clean_all=args.clean_stage.read_bytes(); patched_all=args.patched_stage.read_bytes()
    cs=starts(clean_all); ps=starts(patched_all)
    clean_members={member_name(clean_all[s:(cs[i+1] if i+1<len(cs) else len(clean_all))]):clean_all[s:(cs[i+1] if i+1<len(cs) else len(clean_all))] for i,s in enumerate(cs)}
    pairs=load_pairs(args.dte); rebuilt=[]; expanded=0; affected=set(); continuations=[]
    for i,s in enumerate(ps):
        end=ps[i+1] if i+1<len(ps) else len(patched_all); member=bytearray(patched_all[s:end]); name=member_name(member)
        clean=clean_members[name]; load=struct.unpack_from("<I",clean,8)[0]
        insertions={}
        for row in wanted.get(name,[]):
            command=locate(clean,load,int(row["member_offset"],0))
            if command is None:
                raise SystemExit(f"{name}: no unique dialogue command for {row['id']}")
            insertions[command]=pages[row["source"]]
        string_pool={}
        original_size=len(member)
        for command,page_texts in sorted(insertions.items()):
            encoded=[]
            for page in page_texts:
                if page:
                    raw,_=encode_whole_page(page,pairs); encoded.append(raw)
            if not encoded:
                continue
            record=bytes(member[command:command+24])
            record_offsets=[]
            for _ in encoded:
                record_at=align(len(member),8)
                member.extend(b"\0"*(record_at-len(member)))
                member.extend(record)
                record_offsets.append(record_at)
            for index,(field,raw) in enumerate(zip(record_offsets,encoded)):
                if raw not in string_pool:
                    string_at=align(len(member),8)
                    member.extend(b"\0"*(string_at-len(member)))
                    member.extend(raw+b"\0")
                    string_pool[raw]=string_at
                struct.pack_into("<I",member,field+16,load+string_pool[raw])
                next_page=(record_offsets[index+1] if index+1<len(record_offsets)
                           else command+24)
                # By the time the completion wrapper runs, the event cursor
                # already points one 0x18-byte command beyond the page being
                # displayed. Match that advanced cursor, not the page record.
                continuations.append((load+field+24,load+next_page))
                expanded+=1
            continuations.append((load+command+24,load+record_offsets[0]))
            affected.add(name)
        if insertions:
            size=align(len(member)); member.extend(b"\0"*(size-len(member)))
            growth=size-original_size
            struct.pack_into("<I",member,0x10,struct.unpack_from("<I",clean,0x10)[0]+growth)
            struct.pack_into("<I",member,0x18,load+size); struct.pack_into("<I",member,0x1c,load+size)
        rebuilt.append(bytes(member))
    missing=set(wanted)-affected
    if missing: raise SystemExit("no safe page blocks in: "+", ".join(sorted(missing)))
    args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_bytes(b"".join(rebuilt))
    if args.continuations:
        args.continuations.parent.mkdir(parents=True,exist_ok=True)
        args.continuations.write_text(json.dumps(continuations,indent=2)+"\n",encoding="utf-8")
    print(f"inserted {expanded} dialogue page records in {len(affected)} overlays; STAGE.BIN {len(patched_all)} -> {args.output.stat().st_size}")

if __name__ == "__main__": main()
