#!/usr/bin/env python3
"""Build the editable translation workflow ZIP from an explicit safe manifest."""

from __future__ import annotations

import argparse
import hashlib
import os
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
PREFIX = "dai2-alpha-english-editable-patch"
FORBIDDEN = {".iso", ".bin", ".p04", ".c16", ".p24", ".img", ".mdf", ".p2s", ".ps2", ".elf"}


def manifest() -> list[Path]:
    files = [ROOT / "PACKAGE-README.md", ROOT / "README.md", ROOT / "TSV-EDITOR-README.md"]
    for directory in ("assets", "config", "data", "docs", "patches", "translation", "third_party"):
        files.extend(path for path in (ROOT / directory).rglob("*")
                     if path.is_file() and not any(part.startswith(".") or ":" in part
                                                  for part in path.relative_to(ROOT).parts))
    files.extend(path for path in (ROOT / "tools").glob("*.py") if path.is_file())
    files.extend(path for path in (ROOT / "tools").glob("*.sh") if path.is_file())
    files.extend(path for path in (ROOT / "tools").glob("*.html") if path.is_file())
    files.extend(path for path in (ROOT / "tools").glob("*.js") if path.is_file())
    if (ROOT / "tools/xdelta3").is_file():
        files.append(ROOT / "tools/xdelta3")
    return sorted(set(files))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, nargs="?",
                        default=ROOT / "release/dai2-alpha-english-editable-patch.zip")
    args = parser.parse_args()
    files = manifest()
    forbidden = [path for path in files if path.suffix.lower() in FORBIDDEN]
    if forbidden:
        parser.error("forbidden game-image files in manifest: " + ", ".join(map(str, forbidden)))
    if any(path.is_symlink() or ROOT not in path.resolve().parents for path in files):
        parser.error("package manifest must contain regular files inside the project")
    if args.output.is_dir():
        parser.error(f"output is a directory; move it aside before packaging: {args.output}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Stable timestamps/modes and an internal hash inventory make the release
    # repeatable and allow recipients to check every extracted file.
    inventory = []
    with tempfile.NamedTemporaryFile(dir=args.output.parent, suffix=".zip", delete=False) as temp:
        temporary = Path(temp.name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            def write(name: str, data: bytes, executable: bool = False) -> None:
                info = zipfile.ZipInfo(f"{PREFIX}/{name}", date_time=(2026, 9, 13, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (0o100755 if executable else 0o100644) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, data, compresslevel=9)

            for path in files:
                relative = path.relative_to(ROOT).as_posix()
                data = path.read_bytes()
                inventory.append(f"{hashlib.sha256(data).hexdigest()}  {relative}\n")
                write(relative, data, path.suffix == ".sh" or relative == "tools/xdelta3")
            write("SHA256SUMS", "".join(inventory).encode("utf-8"))
        temporary.chmod(0o644)
        os.replace(temporary, args.output)
    finally:
        temporary.unlink(missing_ok=True)
    checksum = hashlib.sha256(args.output.read_bytes()).hexdigest()
    # Paths are relative to the project root when using the default output.
    try:
        checksum_path = args.output.resolve().relative_to(ROOT)
    except ValueError:
        checksum_path = args.output.resolve()
    args.output.with_suffix(args.output.suffix + ".sha256").write_text(
        f"{checksum}  {checksum_path}\n", encoding="utf-8"
    )
    print(f"packed {len(files)} files into {args.output}")
    print(f"SHA-256: {checksum}")


if __name__ == "__main__":
    main()
