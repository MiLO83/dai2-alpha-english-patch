#!/usr/bin/env python3
"""Install the experimental dialogue completion continuation hook."""

import argparse, json, struct
from pathlib import Path

BASE_VA = 0x00100000
BASE_FILE = 0x1900
HOOK_VA = 0x00208364
CAVE_VA = 0x002DD388

def r(rs, rt, rd, funct, shamt=0): return (rs << 21) | (rt << 16) | (rd << 11) | (shamt << 6) | funct
def i(op, rs, rt, imm): return (op << 26) | (rs << 21) | (rt << 16) | (imm & 0xffff)
def j(op, target): return (op << 26) | ((target >> 2) & 0x03ffffff)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('input',type=Path); ap.add_argument('output',type=Path)
    ap.add_argument('--continuations',type=Path,required=True)
    args=ap.parse_args(); elf=bytearray(args.input.read_bytes())
    mappings=[tuple(x) for x in json.loads(args.continuations.read_text(encoding='utf-8'))]
    if not mappings: ap.error('continuation map is empty')
    def off(va): return BASE_FILE + va - BASE_VA
    # jal 0x2059d0; nop -- the script-owner completion wrapper's sole
    # advance call.  Hooking 0x2059d0 itself is incorrect because the same
    # primitive is also used while commands are pre-scanned.
    original=struct.pack('<II', j(0x03, 0x002059D0), 0)
    if elf[off(HOOK_VA):off(HOOK_VA)+8] != original:
        ap.error('dialogue advance hook signature mismatch')
    table_va=CAVE_VA+0x48
    used=0x48+8*len(mappings)
    if any(elf[off(CAVE_VA):off(CAVE_VA)+used]):
        ap.error('dialogue continuation code cave is not empty')
    # a0 is the nested script state. Match its exact current-command address
    # against an external table; no original command fields are repurposed.
    # Store target-24 because the stock routine performs the final +24.
    words=[
        i(0x23,4,2,0x0c),              # lw v0,0xc(a0)
        i(0x0f,0,8,table_va>>16),       # lui t0,table_hi
        i(0x0d,8,8,table_va&0xffff),    # ori t0,t0,table_lo
        i(0x09,0,9,len(mappings)),      # addiu t1,zero,count
        i(0x23,8,1,0),                 # loop: lw at,0(t0)
        i(0x04,2,1,6),                 # beq v0,at,match
        i(0x09,8,8,8),                 # delay: advance to next pair
        i(0x09,9,9,-1),                # addiu t1,t1,-1
        i(0x05,9,0,-5),                # bnez t1,loop
        0,
        j(0x02,0x002059D0),             # no match: stock advance
        0,
        i(0x23,8,3,-4),                # match: target in prior pair's +4
        i(0x09,3,3,-0x18),             # addiu v1,v1,-24
        i(0x2b,4,3,0x0c),              # sw v1,0xc(a0)
        j(0x02,0x002059D0),             # stock advance
        0,
    ]
    struct.pack_into('<II',elf,off(HOOK_VA),j(0x03,CAVE_VA),0)
    struct.pack_into(f'<{len(words)}I',elf,off(CAVE_VA),*words)
    flat=[word for pair in mappings for word in pair]
    struct.pack_into(f'<{len(flat)}I',elf,off(table_va),*flat)
    args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_bytes(elf)
    print(f'installed dialogue continuation hook at {HOOK_VA:#x}, cave {CAVE_VA:#x}')

if __name__ == '__main__': main()
