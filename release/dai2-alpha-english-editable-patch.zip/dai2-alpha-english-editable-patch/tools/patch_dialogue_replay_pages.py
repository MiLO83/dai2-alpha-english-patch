#!/usr/bin/env python3
"""Install distinct resident Page B/C commands between original dialogues."""

from __future__ import annotations

import argparse
import json
import struct
from pathlib import Path


HOOK_VA = 0x00208364
STOCK_ADVANCE = 0x002059D0
MAIN_VA = 0x00100000
MAIN_FILE = 0x1900
RESIDENT_VA = 0x01E00000


def i(op: int, rs: int, rt: int, immediate: int) -> int:
    return (op << 26) | (rs << 21) | (rt << 16) | (immediate & 0xFFFF)


def j(op: int, target: int) -> int:
    return (op << 26) | ((target >> 2) & 0x03FFFFFF)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()

    elf = bytearray(args.input.read_bytes())
    entries = json.loads(args.manifest.read_text(encoding="utf-8"))
    if not entries:
        args.output.write_bytes(elf)
        print("no resident dialogue pages requested")
        return
    if elf[:6] != b"\x7fELF\x01\x01":
        parser.error("expected a little-endian ELF32 executable")

    phoff = struct.unpack_from("<I", elf, 0x1C)[0]
    phentsize, phnum = struct.unpack_from("<HH", elf, 0x2A)
    main = list(struct.unpack_from("<8I", elf, phoff))
    if main[0] != 1 or main[1] != MAIN_FILE or main[2] != MAIN_VA:
        parser.error("unexpected main LOAD segment")
    if phentsize != 0x20:
        parser.error("unexpected program-header size")
    new_phdr = phoff + phentsize * phnum
    if new_phdr + phentsize > MAIN_FILE:
        parser.error("ELF has no spare program-header slot")
    payload_file = MAIN_FILE + main[4]
    if payload_file >= len(elf):
        parser.error("ELF has no metadata tail available for resident pages")

    def file_offset(va: int) -> int:
        return MAIN_FILE + va - MAIN_VA

    original_hook = struct.pack("<II", j(0x03, STOCK_ADVANCE), 0)
    if elf[file_offset(HOOK_VA):file_offset(HOOK_VA) + 8] != original_hook:
        parser.error("dialogue completion hook signature mismatch")

    page_count = sum(len(entry["pages"]) for entry in entries)
    mapping_count = page_count + len(entries)
    if mapping_count > 32767:
        parser.error("too many dialogue page mappings")
    # Resolve the actual displayed command, using the same two modes as the
    # stock getter at 0x205a40. In queue mode +0xc is a prescan cursor, NOT
    # the displayed command. Keep the queue index fixed until all inserts end.
    words = []
    labels = {}
    branches = []

    def emit(word):
        words.append(word)

    def label(name):
        labels[name] = len(words)

    def branch(op, rs, rt, name):
        branches.append((len(words), op, rs, rt, name))
        emit(0)

    emit(i(0x24, 4, 10, 4))             # lbu t2,4(a0): queue mode
    branch(4, 10, 0, "linear")
    emit(0)
    emit(i(0x23, 4, 10, 0xd8))          # queue index
    emit(i(0x0b, 10, 1, 17))            # sltiu at,t2,17 (also rejects negatives)
    branch(4, 1, 0, "stock")
    emit(0)
    emit((10 << 16) | (10 << 11) | (2 << 6))  # sll t2,t2,2
    emit((10 << 21) | (4 << 16) | (10 << 11) | 0x21)  # addu t2,t2,a0
    branch(4, 0, 0, "lookup")
    emit(i(9, 10, 10, 0x94))            # delay: address of active queue slot
    label("linear")
    emit(i(9, 4, 10, 0xc))              # address of current-command slot
    label("lookup")
    emit(i(0x23, 10, 2, 0))
    address_words = len(words)
    emit(0)
    emit(0)
    emit(i(9, 0, 9, mapping_count))
    label("loop")
    emit(i(0x23, 8, 1, 0))
    branch(5, 2, 1, "next")
    emit(0)
    # Scenario members reuse RAM addresses. Match the loaded member name too.
    emit(i(0x23, 8, 11, 12))            # t3: live member-name address
    emit(i(9, 8, 12, 16))              # t4: expected 32-byte member name
    emit(i(9, 0, 15, 8))
    label("name")
    emit(i(0x23, 11, 13, 0))
    emit(i(0x23, 12, 14, 0))
    branch(5, 13, 14, "next")
    emit(0)
    emit(i(9, 11, 11, 4))
    emit(i(9, 12, 12, 4))
    emit(i(9, 15, 15, -1))
    branch(5, 15, 0, "name")
    emit(0)
    emit(i(0x23, 8, 2, 4))             # next page, or restored original
    emit(i(0x23, 8, 3, 8))             # final-page flag
    emit(i(0x2b, 10, 2, 0))            # update only the active slot
    branch(5, 3, 0, "stock")           # final: stock advances original sequence
    emit(0)
    emit(0x03e00008)                   # jr ra: show insert without advancing queue
    emit(0)
    label("next")
    emit(i(9, 8, 8, 48))
    emit(i(9, 9, 9, -1))
    branch(5, 9, 0, "loop")
    emit(0)
    label("stock")
    emit(j(2, STOCK_ADVANCE))
    emit(0)
    for position, op, rs, rt, target in branches:
        words[position] = i(op, rs, rt, labels[target] - position - 1)
    code_size = len(words) * 4
    table_va = RESIDENT_VA + code_size
    records_va = table_va + mapping_count * 48
    records = bytearray()
    strings = bytearray()
    mappings = bytearray()
    record_index = 0
    strings_va = records_va + page_count * 24
    for entry in entries:
        template = bytes.fromhex(entry["record"])
        if len(template) != 24 or struct.unpack_from("<I", template, 8)[0] != 1:
            parser.error(f"{entry['id']}: invalid dialogue command template")
        member_name = bytes.fromhex(entry["member_name_hex"])
        if len(member_name) != 32:
            parser.error(f"{entry['id']}: invalid member-name signature")

        def mapping(current, target, resume):
            mappings.extend(struct.pack("<4I", current, target, resume,
                                        int(entry["member_name_pointer"])))
            mappings.extend(member_name)

        resident_commands = []
        for page in entry["pages"]:
            command_va = records_va + record_index * 24
            record_index += 1
            resident_commands.append(command_va)
            record = bytearray(template)
            raw = bytes.fromhex(page["encoded"])
            text_va = strings_va + len(strings)
            struct.pack_into("<I", record, 16, text_va)
            records.extend(record)
            strings.extend(raw + b"\0")
        mapping(int(entry["command"]), resident_commands[0], 0)
        for index, command_va in enumerate(resident_commands):
            target = (resident_commands[index + 1] if index + 1 < len(resident_commands)
                      else int(entry["command"]))
            mapping(command_va, target, int(index + 1 == len(resident_commands)))

    words[address_words] = i(0x0F, 0, 8, table_va >> 16)
    words[address_words + 1] = i(0x0D, 8, 8, table_va & 0xFFFF)
    payload = struct.pack(f"<{len(words)}I", *words)
    payload += mappings
    payload += records + strings
    if payload_file + len(payload) > len(elf):
        parser.error(f"resident dialogue payload needs {len(payload)} bytes")

    elf[payload_file:payload_file + len(payload)] = payload
    struct.pack_into("<8I", elf, new_phdr, 1, payload_file, RESIDENT_VA, RESIDENT_VA,
                     len(payload), len(payload), 7, 0x80)
    struct.pack_into("<H", elf, 0x2C, phnum + 1)
    struct.pack_into("<I", elf, 0x20, 0)
    struct.pack_into("<HHH", elf, 0x2E, 0, 0, 0)
    struct.pack_into("<II", elf, file_offset(HOOK_VA), j(0x03, RESIDENT_VA), 0)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(elf)
    print(f"installed {page_count} distinct resident dialogue command(s)")
    print(f"resident payload: {len(payload)} bytes in new LOAD segment {phnum}")


if __name__ == "__main__":
    main()
