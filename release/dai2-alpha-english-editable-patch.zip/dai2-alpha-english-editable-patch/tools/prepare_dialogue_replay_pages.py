#!/usr/bin/env python3
"""Describe hand-translated pages after the first nonempty replacement page."""

from __future__ import annotations

import argparse
import csv
import json
import struct
from collections import defaultdict
from pathlib import Path

from dte_codec import encode_whole_page, load_pairs
from editable_translation import hand_translated_pages


def starts(data: bytes) -> list[int]:
    result: list[int] = []
    position = 0
    while (position := data.find(b"MWo3", position)) >= 0:
        result.append(position)
        position += 4
    return result


def name_of(member: bytes) -> str:
    return member[0x20:0x40].split(b"\0", 1)[0].decode("ascii", "replace")


def locate(clean: bytes, load: int, text_offset: int) -> int | None:
    matches: list[int] = []
    target = load + text_offset
    for reference in range(16, len(clean) - 3, 4):
        if struct.unpack_from("<I", clean, reference)[0] != target:
            continue
        command = reference - 16
        if struct.unpack_from("<I", clean, command + 8)[0] == 1:
            matches.append(command)
    unique = list(dict.fromkeys(matches))
    return unique[0] if len(unique) == 1 else None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("clean_stage", type=Path)
    parser.add_argument("patched_stage", type=Path)
    parser.add_argument("occurrences", type=Path)
    parser.add_argument("table", type=Path)
    parser.add_argument("dte", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    with args.table.open(encoding="utf-8-sig", newline="") as source:
        rows = list(csv.DictReader(source, dialect="excel-tab"))
    requested = {
        row["Original Japanese"]: pages[1:]
        for row in rows
        if row.get("Scope", "dialogue") == "dialogue"
        and len(pages := hand_translated_pages(row)) > 1
    }
    if not requested:
        args.output.write_text("[]\n", encoding="utf-8")
        print("no replay pages requested")
        return

    with args.occurrences.open(encoding="utf-8", newline="") as source:
        occurrences = list(csv.DictReader(source, dialect="excel-tab"))
    wanted: dict[str, list[dict[str, str]]] = defaultdict(list)
    matched: set[str] = set()
    for row in occurrences:
        if row["source"] in requested:
            wanted[row["member"]].append(row)
            matched.add(row["source"])
    absent = set(requested) - matched
    if absent:
        raise SystemExit(f"extra pages are dialogue-only; {len(absent)} source(s) were not found")

    clean_all = args.clean_stage.read_bytes()
    patched_all = args.patched_stage.read_bytes()
    clean_starts = starts(clean_all)
    patched_starts = starts(patched_all)
    clean_members = {
        name_of(clean_all[begin:(clean_starts[i + 1] if i + 1 < len(clean_starts) else len(clean_all))]):
        clean_all[begin:(clean_starts[i + 1] if i + 1 < len(clean_starts) else len(clean_all))]
        for i, begin in enumerate(clean_starts)
    }
    pairs = load_pairs(args.dte)
    manifest: list[dict[str, object]] = []
    affected: set[str] = set()
    for i, begin in enumerate(patched_starts):
        end = patched_starts[i + 1] if i + 1 < len(patched_starts) else len(patched_all)
        member = patched_all[begin:end]
        member_name = name_of(member)
        clean = clean_members[member_name]
        load = struct.unpack_from("<I", clean, 8)[0]
        for row in wanted.get(member_name, []):
            command = locate(clean, load, int(row["member_offset"], 0))
            if command is None:
                raise SystemExit(f"{member_name}: no unique dialogue command for {row['id']}")
            pages = []
            for text in requested[row["source"]]:
                if text:
                    encoded, _ = encode_whole_page(text, pairs)
                    pages.append({"text": text, "encoded": encoded.hex()})
            if not pages:
                continue
            page_one_pointer = struct.unpack_from("<I", member, command + 16)[0]
            manifest.append({
                "id": row["id"],
                "member": member_name,
                "member_name_pointer": load + 0x20,
                "member_name_hex": bytes(member[0x20:0x40]).hex(),
                "command": load + command,
                "cursor": load + command + 24,
                "page_one_pointer": page_one_pointer,
                "record": bytes(member[command:command + 24]).hex(),
                "pages": pages,
            })
            affected.add(member_name)

    missing = set(wanted) - affected
    if missing:
        raise SystemExit("no safe replay commands in: " + ", ".join(sorted(missing)))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"prepared {sum(len(item['pages']) for item in manifest)} replay page(s) for {len(manifest)} dialogue command(s)")


if __name__ == "__main__":
    main()
