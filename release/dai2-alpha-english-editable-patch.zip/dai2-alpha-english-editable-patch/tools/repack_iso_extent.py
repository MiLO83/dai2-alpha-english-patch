#!/usr/bin/env python3
"""Replace an ISO9660 file in place and reserve sectors immediately after it.

All sectors before the target file remain at their original LBAs. Later extents
are shifted as a unit and every affected ISO9660 directory/path-table address is
updated. The target's logical length is the replacement length; reserve space is
an unreferenced physical gap, not padding exposed to the game as file data.
"""

from __future__ import annotations

import argparse
import hashlib
import mmap
import shutil
import struct
from pathlib import Path

SECTOR = 2048


def u32le(data: bytes | bytearray, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def put_both_u32(data: bytearray, off: int, value: int) -> None:
    struct.pack_into("<I", data, off, value)
    struct.pack_into(">I", data, off + 4, value)


def walk_directory(iso: bytes, extent: int, size: int, seen: set[int]):
    if extent in seen:
        return
    seen.add(extent)
    start = extent * SECTOR
    blob = iso[start : start + size]
    pos = 0
    while pos < len(blob):
        length = blob[pos]
        if not length:
            pos = (pos // SECTOR + 1) * SECTOR
            continue
        if pos + length > len(blob) or length < 34:
            raise ValueError(f"invalid directory record at LBA {extent}+0x{pos:X}")
        rec = blob[pos : pos + length]
        child_extent = u32le(rec, 2)
        child_size = u32le(rec, 10)
        flags = rec[25]
        name_len = rec[32]
        name = bytes(rec[33 : 33 + name_len])
        yield start + pos, child_extent, child_size, flags, name
        if flags & 2 and name not in (b"\x00", b"\x01"):
            yield from walk_directory(iso, child_extent, child_size, seen)
        pos += length


def patch_path_table(data: bytearray, off: int, size: int, big: bool,
                     threshold: int, shift: int) -> None:
    pos = off
    end = off + size
    fmt = ">I" if big else "<I"
    while pos + 8 <= end:
        name_len = data[pos]
        if not name_len:
            break
        extent = struct.unpack_from(fmt, data, pos + 2)[0]
        if extent >= threshold:
            struct.pack_into(fmt, data, pos + 2, extent + shift)
        pos += 8 + name_len + (name_len & 1)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("iso", type=Path)
    ap.add_argument("replacement", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--iso-name", required=True, help="identifier including ;1")
    ap.add_argument("--reserve", type=lambda x: int(x, 0), default=8 * 1024 * 1024,
                    help="physical headroom after the file (default: 8 MiB)")
    args = ap.parse_args()

    replacement = args.replacement.read_bytes()
    source_size = args.iso.stat().st_size
    if source_size % SECTOR:
        ap.error("source ISO is not sector aligned")
    with args.iso.open("rb") as source_file:
        source = mmap.mmap(source_file.fileno(), 0, access=mmap.ACCESS_READ)
        pvd = 16 * SECTOR
        if source[pvd + 1 : pvd + 6] != b"CD001":
            ap.error("primary ISO9660 volume descriptor not found")
        root = source[pvd + 156 : pvd + 190]
        root_extent, root_size = u32le(root, 2), u32le(root, 10)
        records = list(walk_directory(source, root_extent, root_size, set()))
        needle = args.iso_name.encode("ascii")
        matches = [r for r in records if r[4] == needle]
        if len(matches) != 1:
            ap.error(f"expected one {args.iso_name!r} record, found {len(matches)}")
        target_record, target_extent, old_size, _, _ = matches[0]
        old_sectors = (old_size + SECTOR - 1) // SECTOR
        new_sectors = (len(replacement) + SECTOR - 1) // SECTOR
        reserve_sectors = (args.reserve + SECTOR - 1) // SECTOR
        occupied_sectors = max(old_sectors, new_sectors + reserve_sectors)
        shift = occupied_sectors - old_sectors
        threshold = target_extent + old_sectors
        insertion = threshold * SECTOR
        volume_sectors = source_size // SECTOR + shift
        target_start = target_extent * SECTOR
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("wb") as out:
            out.write(source[:target_start])
            out.write(replacement)
            out.write(bytes(new_sectors * SECTOR - len(replacement)))
            out.write(bytes((occupied_sectors - new_sectors) * SECTOR))
            source.seek(insertion)
            shutil.copyfileobj(source, out, length=16 * 1024 * 1024)
        source.close()

    with args.output.open("r+b") as output_file:
        data = mmap.mmap(output_file.fileno(), 0)
        def shifted_offset(off: int) -> int:
            return off + shift * SECTOR if off >= insertion else off
        put_both_u32(data, shifted_offset(target_record) + 10, len(replacement))
        for rec_off, extent, _, _, name in records:
            if name != needle and extent >= threshold:
                put_both_u32(data, shifted_offset(rec_off) + 2, extent + shift)
        vd_lba = 16
        while True:
            off = vd_lba * SECTOR
            if data[off + 1 : off + 6] != b"CD001":
                break
            kind = data[off]
            if kind in (1, 2):
                put_both_u32(data, off + 80, volume_sectors)
                path_size = u32le(data, off + 132)
                for field, big in ((140, False), (144, False), (148, True), (152, True)):
                    fmt = ">I" if big else "<I"
                    table_lba = struct.unpack_from(fmt, data, off + field)[0]
                    if table_lba:
                        table_off = shifted_offset(table_lba * SECTOR)
                        if table_lba >= threshold:
                            struct.pack_into(fmt, data, off + field, table_lba + shift)
                        patch_path_table(data, table_off, path_size, big, threshold, shift)
            vd_lba += 1
            if kind == 255:
                break
        data.flush()
        data.close()
    if args.output.stat().st_size != volume_sectors * SECTOR:
        raise AssertionError("rebuilt ISO length mismatch")
    print(f"{args.iso_name}: LBA {target_extent}, {old_size} -> {len(replacement)} bytes")
    print(f"reserved after file: {(occupied_sectors-new_sectors)*SECTOR} bytes")
    print(f"shifted later extents by {shift} sectors ({shift*SECTOR} bytes)")
    digest = hashlib.sha256()
    with args.output.open("rb") as output_file:
        for chunk in iter(lambda: output_file.read(16 * 1024 * 1024), b""):
            digest.update(chunk)
    print(f"output SHA-256: {digest.hexdigest()}")


if __name__ == "__main__":
    main()
