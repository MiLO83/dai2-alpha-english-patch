"""Check box limits and execute the emitted MIPS redirect with delay slots."""

import csv
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import editable_translation as editor
import prepare_dialogue_replay_pages as replay
from editable_translation import validate_dialogue_page
from patch_dialogue_replay_pages import HOOK_VA, MAIN_FILE, MAIN_VA, RESIDENT_VA, STOCK_ADVANCE, j


class DialoguePagesTest(unittest.TestCase):
    def test_sparse_hand_translations_replace_machine_and_skip_blanks(self):
        # All eight combinations, including whitespace-only gaps and fallback.
        rows = []
        for mask in range(8):
            rows.append(dict(zip(editor.PAGE_HEADERS, [
                f'source{mask}', 'Machine',
                *[text if mask & (1 << index) else '  '
                  for index, text in enumerate(('AA', 'BB', 'CC'))],
            ])))
        rows.append(dict(zip(editor.PAGE_HEADERS, ['Untranslated', '', '', '', ''])))
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            table = root / 'table.tsv'
            with table.open('w', newline='') as output:
                writer = csv.DictWriter(output, fieldnames=editor.PAGE_HEADERS, dialect='excel-tab')
                writer.writeheader()
                writer.writerows(rows)

            class SelectionComplete(Exception):
                pass

            # Stop before expensive font/ISO assembly, inspect its real inputs.
            with patch.object(editor, 'ROOT', root), \
                 patch.object(editor, 'sha256', return_value=editor.SOURCE_ISO_SHA256), \
                 patch.object(editor, 'extract_verified'), \
                 patch.object(editor, 'run', side_effect=SelectionComplete):
                with self.assertRaises(SelectionComplete):
                    editor.build(table, root / 'no-ui', root / 'source.iso',
                                 root / 'output.iso', False, root / 'font.ttf')
            work = root / 'work/editor-build'
            selected = {row['source']: row['translation'] for row in
                        map(json.loads, (work / 'selected-translations.jsonl').read_text().splitlines())}
            expected_extras = []
            for mask in range(8):
                pages = [text for index, text in enumerate(('AA', 'BB', 'CC')) if mask & (1 << index)]
                self.assertEqual(selected[f'source{mask}'], pages[0] if pages else 'Machine')
                expected_extras.extend(pages[1:])
            self.assertNotIn('Untranslated', selected)
            self.assertEqual(list(map(json.loads, (work / 'extra-pages.jsonl').read_text().splitlines())),
                             expected_extras)

            # Feed the same table through actual replay-manifest preparation.
            stage = bytearray(0x400)
            stage[:4] = b'MWo3'
            struct.pack_into('<I', stage, 8, 0x780000)
            stage[0x20:0x29] = b'stage.bin'
            occurrences = []
            for mask in range(8):
                command, text_offset = 0x40 + mask * 24, 0x300 + mask * 8
                struct.pack_into('<6I', stage, command, 1, 0, 1, 0, 0x780000 + text_offset, 0)
                occurrences.append({'id': str(mask), 'member': 'stage.bin',
                                    'member_offset': hex(text_offset), 'source': f'source{mask}'})
            (root / 'stage').write_bytes(stage)
            with (root / 'occurrences').open('w', newline='') as output:
                writer = csv.DictWriter(output, fieldnames=occurrences[0], dialect='excel-tab')
                writer.writeheader()
                writer.writerows(occurrences)
            (root / 'dte').write_text('pair\tsjis\nAA\t8260\nBB\t8261\nCC\t8262\n')
            with patch.object(sys, 'argv', ['prepare', str(root / 'stage'), str(root / 'stage'),
                                           str(root / 'occurrences'), str(table), str(root / 'dte'),
                                           str(root / 'manifest')]):
                replay.main()
            manifest = json.loads((root / 'manifest').read_text())
            self.assertEqual({entry['id']: [page['text'] for page in entry['pages']] for entry in manifest},
                             {'3': ['BB'], '5': ['CC'], '6': ['CC'], '7': ['BB', 'CC']})

    def test_box_limits(self):
        validate_dialogue_page('「' + '\n'.join(['A' * 44] * 3) + '」', 2, 'English')
        for text in ('A' * 45, 'a\nb\nc\nd'):
            with self.assertRaises(SystemExit):
                validate_dialogue_page(text, 2, 'English Page 3')

    def test_completion_preserves_original_order_in_both_modes(self):
        elf = bytearray(0x120000)
        elf[:6] = b'\x7fELF\x01\x01'
        struct.pack_into('<I', elf, 0x1C, 0x34)
        struct.pack_into('<HH', elf, 0x2A, 32, 1)
        struct.pack_into('<8I', elf, 0x34, 1, MAIN_FILE, MAIN_VA, MAIN_VA,
                         0x110000, 0x110000, 7, 0x80)
        struct.pack_into('<II', elf, MAIN_FILE + HOOK_VA - MAIN_VA,
                         j(3, STOCK_ADVANCE), 0)
        command = 0x780100
        record = struct.pack('<6I', 1, 0, 1, 0x1AD, 0x784000, 0).hex()
        entries = []
        for name, offset, pages in [('stage.bin', 0, ['8260', '8261']),
                                     ('stage.bin', 24, ['8262']),
                                     ('other.bin', 0, ['8263'])]:
            entries.append({'id': name + str(offset), 'command': command + offset,
                            'member_name_pointer': 0x780020,
                            'member_name_hex': name.encode().ljust(32, b'\0').hex(),
                            'record': record, 'pages': [{'encoded': raw} for raw in pages]})
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'input').write_bytes(elf)
            (root / 'manifest').write_text(json.dumps(entries))
            subprocess.run([sys.executable, str(Path(__file__).with_name('patch_dialogue_replay_pages.py')),
                            str(root / 'input'), str(root / 'output'), '--manifest', str(root / 'manifest')],
                           check=True, capture_output=True)
            payload = (root / 'output').read_bytes()[MAIN_FILE + 0x110000:]

            def word(address):
                return struct.unpack_from('<I', payload, address - RESIDENT_VA)[0]

            def complete(state):
                regs = [0] * 32
                regs[4], regs[31] = 0x1000, HOOK_VA + 8
                pc, pending = RESIDENT_VA, None
                for _ in range(1000):
                    if pc == STOCK_ADVANCE:
                        self.assertEqual(regs[31], HOOK_VA + 8)
                        if state[0x1004]:
                            state[0x10D8] += 1
                            return state.get(0x1094 + 4 * state[0x10D8], 0)
                        state[0x100C] += 24
                        return state[0x100C]
                    if pc == HOOK_VA + 8:
                        return regs[2]
                    instruction = word(pc)
                    op, rs, rt = instruction >> 26, instruction >> 21 & 31, instruction >> 16 & 31
                    rd = instruction >> 11 & 31
                    imm = instruction & 0xFFFF
                    signed = imm if imm < 0x8000 else imm - 0x10000
                    branch = None
                    if op in (0x23, 0x24):
                        address = (regs[rs] + signed) & 0xFFFFFFFF
                        regs[rt] = state[address] if address in state else word(address)
                        if op == 0x24:
                            regs[rt] &= 0xFF
                    elif op == 0x2B:
                        state[regs[rs] + signed] = regs[rt]
                    elif op == 0x0F:
                        regs[rt] = imm << 16
                    elif op == 0x0D:
                        regs[rt] = regs[rs] | imm
                    elif op == 0x0B:
                        regs[rt] = int(regs[rs] < (signed & 0xFFFFFFFF))
                    elif op == 9:
                        regs[rt] = (regs[rs] + signed) & 0xFFFFFFFF
                    elif op in (4, 5):
                        if (regs[rs] == regs[rt]) == (op == 4):
                            branch = pc + 4 + signed * 4
                    elif op == 2:
                        branch = (instruction & 0x3FFFFFF) << 2
                    elif op == 0 and instruction & 63 == 0x21:
                        regs[rd] = (regs[rs] + regs[rt]) & 0xFFFFFFFF
                    elif op == 0 and instruction & 63 == 0:
                        regs[rd] = (regs[rt] << (instruction >> 6 & 31)) & 0xFFFFFFFF
                    elif op == 0 and instruction & 63 == 8:
                        branch = regs[rs]
                    else:
                        self.fail(f'unsupported instruction {instruction:#x}')
                    regs[0] = 0
                    pc = pending if pending is not None else pc + 4
                    pending = branch
                self.fail('completion did not return')

            for mode in (0, 1):
                for name, expected in [('stage.bin', ['8260', '8261']), ('other.bin', ['8263']),
                                       ('unrelated.bin', [])]:
                    with self.subTest(mode=mode, member=name):
                        # The queued mode cursor deliberately points far ahead.
                        state = {0x1004: mode, 0x100C: 0x78F000 if mode else command,
                                 0x10D8: 0, 0x1094: command, 0x1098: command + 24,
                                 0x109C: command + 48}
                        signature = name.encode().ljust(32, b'\0')
                        state.update({0x780020 + n: struct.unpack_from('<I', signature, n)[0]
                                      for n in range(0, 32, 4)})
                        for revisit in range(2):
                            state[0x10D8] = 0
                            if not mode:
                                state[0x100C] = command
                            for raw in expected:
                                inserted = complete(state)
                                self.assertGreaterEqual(inserted, RESIDENT_VA)
                                pointer = word(inserted + 16)
                                self.assertEqual(payload[pointer - RESIDENT_VA:pointer - RESIDENT_VA + 2].hex(), raw)
                                self.assertEqual(word(inserted + 12), 0x1AD)
                                self.assertEqual(state[0x10D8], 0)
                                if mode:
                                    self.assertEqual(state[0x100C], 0x78F000)
                            self.assertEqual(complete(state), command + 24)
                            if mode:
                                self.assertEqual(state[0x1094], command)  # restored for loops/revisits
                                self.assertEqual(state[0x10D8], 1)
                                self.assertEqual(state[0x100C], 0x78F000)
                            if name == 'stage.bin':
                                inserted = complete(state)
                                pointer = word(inserted + 16)
                                self.assertEqual(payload[pointer - RESIDENT_VA:pointer - RESIDENT_VA + 2].hex(), '8262')
                            self.assertEqual(complete(state), command + 48)


if __name__ == '__main__':
    unittest.main()
