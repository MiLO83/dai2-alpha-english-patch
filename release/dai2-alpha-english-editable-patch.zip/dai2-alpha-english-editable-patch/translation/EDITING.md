# Editing translation data

Start with the [spreadsheet tutorial](../README.md#tutorial-from-one-edit-to-a-playable-iso).
The recommended master is `all-known-game-text.tsv`; `game-script.tsv` contains
dialogue only, and `ui-script.tsv` contains fixed executable UI text.

## Keep the TSV schema

Use UTF-8 tab-separated values with proper quoting for cells containing line
breaks, quotes, or tabs. The editor exports a UTF-8 BOM and CRLF row separators.
The accepted text headers are:

```text
Original Japanese    Automatic Translation    English    English Page 2    English Page 3
```

Those separators are illustrative; actual files use tabs. The combined master
has `Scope` first, with `dialogue`, `ui`, or `title`. Older three-text-column
files are also accepted. The browser's friendlier labels do not rename the
saved schema. `Original Japanese` is the lookup key: do not rewrite it.

Nonempty hand-translated cells (`English`, `English Page 2`, `English Page 3`)
replace the dialogue entry in order. Whitespace-only cells are empty. The first
nonempty cell is the first replacement page, even if `English` is blank. Only
when all three are empty does `Automatic Translation` supply the text; if that
is empty, the original is retained. Shared dialogue sources affect all mapped
occurrences; rows are not per-scene playback commands.

## Structure and display limits

Keep the source's `$`-letter control-code sequence and `「」` delimiter sequence
in every nonempty manual page. Retain any required speaker structure. Use
ordinary printable ASCII English; the pair encoder does not accept smart
quotes, emoji, or accented letters as visible English segments.

Each manual dialogue page must fit three lines of up to 44 English characters.
Do not assume the numeric fit indicator accounts perfectly for control syntax
or full-width delimiters. The original's line-break positions may be reflowed
within these limits. Review the actual result in-game.

DTE renders two English characters in one glyph tile. It does not remove the
first-page allocation limit, UI field limits, or finite total resident-page
storage. The builder stops if any requested manual occurrence cannot be
inserted. Automatic selections may fall back to Japanese if unsafe or too large.

## Scope limits

UI rows support `English` only and have per-occurrence byte limits recorded in
`../data/ui-occurrences.tsv`. The builder rejects extra UI pages. Its report is
`../work/editor-build/editable-ui-build-report.tsv`.

The `title` scope and `title-script.tsv` retain discovered prologue text for
research. They are not inserted by the current spreadsheet pipeline. The native
English title/intro artwork instead comes from the bundled visual baseline.

The extra-page path preserves original scenario order through resident command
copies and the active-command completion hook. It does not use the historical
overlay-expansion approach. See [runtime notes](../docs/DIALOGUE-PAGES.md).

## Build and inspect

From the project root, use `./tools/build-web-edited-iso.sh` for the complete
editor build. The lower-level `build-edited-iso.sh` omits the visual baseline;
it accepts table, source ISO, and output ISO paths followed by optional `--force`.

Inspect `work/editor-build/editable-build-report.tsv` for scenario insertion
status, `editable-ui-build-report.tsv` for UI status, and
`dialogue-replay-pages.json` for extra-page command mappings. The first page's
report records byte allocation and destination, not its place in gameplay.

`glyph-byte-table.tsv` documents known CP932/DTE glyph bytes and atlas indices.
It is a reference snapshot. Edited builds allocate their own matching pairs in
`work/editor-build/editable-dte.tsv`.

The export/regeneration commands are research utilities. They may depend on
ignored `work/script/` and `work/translation/` files, and `export --force`
replaces an existing table. They are not needed to use the supplied TSVs.
